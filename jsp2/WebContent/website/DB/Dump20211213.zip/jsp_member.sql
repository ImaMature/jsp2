-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: jsp
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `m_num` int NOT NULL AUTO_INCREMENT,
  `m_id` varchar(20) NOT NULL,
  `m_password` varchar(20) NOT NULL,
  `m_name` varchar(20) NOT NULL,
  `m_birth` varchar(20) NOT NULL,
  `m_sex` varchar(10) DEFAULT NULL,
  `m_phone` varchar(20) DEFAULT NULL,
  `m_address` varchar(200) DEFAULT NULL,
  `m_point` int DEFAULT '0',
  `m_sdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`m_num`),
  UNIQUE KEY `m_id` (`m_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (40,'rrrrr','12345','qqq','2021-12-10','woman','cxxzz','a',0,'2021-12-03 05:16:35'),(41,'qwert','12345','aaa','2021-12-10','man','010-0000-0000','06112,서울 강남구 논현로123길 4-1,서울 강남구 논현동 130-26,',0,'2021-12-03 06:09:20'),(42,'aaaaa','aaaaa','aaa','2021-12-03','man','010-0000-0000','14354,경기 광명시 석수로435번길 36-29,경기 광명시 일직동 64-15,aaa',0,'2021-12-08 01:21:54'),(43,'admin','12345','관리자','2021-12-02','man','010-0000-0000','06112,서울 강남구 논현로123길 4-1,서울 강남구 논현동 130-26,',0,'2021-12-09 04:24:00');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-13 10:34:46
