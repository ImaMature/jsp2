-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: jsp
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `p_num` int NOT NULL AUTO_INCREMENT,
  `p_name` varchar(200) NOT NULL,
  `p_price` int NOT NULL,
  `p_category` varchar(100) DEFAULT NULL,
  `p_manufacturer` varchar(200) DEFAULT NULL,
  `p_active` int DEFAULT NULL,
  `p_size` varchar(100) DEFAULT NULL,
  `p_stock` int DEFAULT NULL,
  `p_img` varchar(1000) DEFAULT NULL,
  `p_contents` varchar(1000) DEFAULT NULL,
  `p_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`p_num`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (5,'자차',1200000,'top','BMW',2,'S',122,'car13.jpg','차다.','2021-12-09 04:26:18'),(6,'차차',23333,'pants','qqqq',3,'M',1122,'car25.jpg','ㄷㅈㅂㄷㅂㅈ','2021-12-09 05:03:55'),(8,'qqq',100000,'pants','bmw',1,'M',31,'car54.jpg','qewqw','2021-12-09 06:37:59'),(9,'자동차',1212,'pants','캡',3,'L',55,'car444.jpg','ㅈㅈㅈㅈ','2021-12-09 06:38:51'),(10,'옷',20000,'outer','아이디',1,'L',20,'clothes21.jpg','캐주얼한 옷2','2021-12-09 09:06:32');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-13 10:34:46
