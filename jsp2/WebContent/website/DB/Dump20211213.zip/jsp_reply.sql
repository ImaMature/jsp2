-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: jsp
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reply`
--

DROP TABLE IF EXISTS `reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reply` (
  `r_num` int NOT NULL AUTO_INCREMENT,
  `r_contents` varchar(5000) DEFAULT NULL,
  `r_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `m_num` int NOT NULL,
  `b_num` int NOT NULL,
  PRIMARY KEY (`r_num`),
  KEY `reply_ibfk_2` (`b_num`),
  KEY `reply_ibfk_1` (`m_num`),
  CONSTRAINT `reply_ibfk_1` FOREIGN KEY (`m_num`) REFERENCES `member` (`m_num`) ON DELETE CASCADE,
  CONSTRAINT `reply_ibfk_2` FOREIGN KEY (`b_num`) REFERENCES `board` (`b_num`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reply`
--

LOCK TABLES `reply` WRITE;
/*!40000 ALTER TABLE `reply` DISABLE KEYS */;
INSERT INTO `reply` VALUES (1,'EQWWEQEQW','2021-12-07 08:42:43',40,27),(23,'faffda','2021-12-07 10:18:12',40,28),(24,'','2021-12-07 10:23:16',40,29),(25,'eqw','2021-12-07 10:23:21',40,29),(28,'eqw2eq1e','2021-12-07 11:02:04',40,28),(32,'qq','2021-12-08 01:21:22',40,38),(33,'ww','2021-12-08 01:21:25',40,38),(35,'ewqeqwe','2021-12-08 05:22:39',40,31),(40,'ewqw','2021-12-08 07:04:08',40,39),(41,'ewqeqew','2021-12-08 07:04:10',40,39),(42,'eqwewq','2021-12-08 07:04:13',40,39),(43,'ewqeqwqw','2021-12-08 07:04:16',40,39),(44,'ewqeqw','2021-12-08 07:04:19',40,39),(45,'eqweqw','2021-12-08 07:04:24',40,39),(46,'ewqewq','2021-12-08 07:04:29',40,39),(47,'fsadfa','2021-12-08 07:10:35',40,37),(48,'fdsafadfds','2021-12-08 07:10:40',40,37),(49,'fsdafsafa','2021-12-08 07:10:43',40,37),(50,'fdsaafd','2021-12-08 07:10:46',40,37),(51,'fdsaa','2021-12-08 07:10:49',40,37),(52,'fsd','2021-12-08 07:10:53',40,37),(53,'fdaf','2021-12-08 07:22:54',40,35),(54,'213','2021-12-08 07:22:57',40,35),(55,'ewq','2021-12-08 07:22:59',40,35),(56,'eqwwq','2021-12-08 07:23:01',40,35),(60,'hghgbj','2021-12-08 07:35:15',40,38),(61,'ghjgh','2021-12-08 07:35:18',40,38),(62,'ghjghj','2021-12-08 07:35:20',40,38),(63,'ghjghj','2021-12-08 07:35:22',40,38),(64,'ewqeqw','2021-12-08 07:36:40',42,41),(65,'fdasfdas','2021-12-08 07:38:57',42,31),(66,'fasdfasda','2021-12-08 07:39:24',42,30),(67,'eqweqw','2021-12-08 07:39:56',40,38),(68,'ewqeqw','2021-12-08 07:40:07',42,41),(69,'eqweqw','2021-12-08 07:40:16',42,37),(70,'dassda','2021-12-08 07:42:01',42,38),(74,'ewqe','2021-12-08 07:55:35',40,41);
/*!40000 ALTER TABLE `reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-13 10:34:46
